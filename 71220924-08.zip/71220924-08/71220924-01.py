carikata = input("Masukan kata yang ingin dicari:")

nama_file = 'romeojuliet.txt'
handle = open(nama_file, 'r')
carikata = carikata.lower()

jumlah_kata = 0

for baris in handle:
    baris = baris.lower()
    jumlah_kata = jumlah_kata + baris.count(carikata)
    
    
    
    
    

print (f'kata {carikata} jumlahnya ada: {jumlah_kata}')
handle.close()