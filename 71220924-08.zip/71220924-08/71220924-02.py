hapus_buah = input("Masukan nama buah yang ingin dihapus:")

nama_file = 'buah.txt'
handle = open(nama_file, 'r')

fruit = []


for baris in handle:
    baris = baris.strip()
    fruit.append(baris)

for baris in handle:
    if fruit == hapus_buah:
        fruit = fruit.remove(baris)
    



handle.write(nama_file)
handle.close()

