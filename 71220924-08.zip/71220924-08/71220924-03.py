nama_file = 'nilai.txt'
nama_file = nama_file
handle = open('nilai.txt', 'r')


baris = 1


for line in handle:
    line = line.strip()
    if baris <=6:
        print(f'Nilai tugas {baris} : {line}')
    elif baris == 7:
        print(f'Nilai UTS :{line}')
    elif baris == 8 :
        print(f'Nilai UAS : {line}')
handle.close()


nama_file = 'nilai.txt'
nama_file = nama_file
handle = open('nilai.txt', 'r')

nilai = 0
baris = 1
for angka in handle.readlines():
    angka = int(angka.strip())


    if baris == 1:
        nilai = nilai + (angka*0.05)

    elif  baris == 2:
        nilai = nilai + (angka*0.05)
        
    elif baris == 3:
        nilai = nilai + (angka*0.10)
        
    elif baris == 4:
        nilai = nilai + (angka*0.05)
        
    elif baris == 5:  
        nilai = nilai + (angka*0.15)
        
    elif baris == 6:
        nilai = nilai + (angka*0.10)
        
    elif baris == 7:
        nilai = nilai + (angka*0.22)
        
    elif baris == 8:
        nilai = nilai + (angka*0.28)
        
    baris +1

print(f'nilai akhir{nilai:.2f}')
handle.close

    